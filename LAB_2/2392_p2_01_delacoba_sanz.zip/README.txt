Kevin de la Coba Malam
Juan Luis Sanz Calvar
Group 2392, pair 01.
2392_p2_01_CobaMalam_SanzCalvar.py has the heuristics performed by us.
tester.py is the file used to test the alpha-beta pruning and the minimax